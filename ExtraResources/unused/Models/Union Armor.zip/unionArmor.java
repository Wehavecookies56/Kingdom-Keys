// Made with Blockbench 4.8.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports


public class unionArmor<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "unionarmor"), "main");
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart leftArm;
	private final ModelPart rightArm;
	private final ModelPart leftLeg;
	private final ModelPart rightLeg;

	public unionArmor(ModelPart root) {
		this.head = root.getChild("head");
		this.body = root.getChild("body");
		this.leftArm = root.getChild("leftArm");
		this.rightArm = root.getChild("rightArm");
		this.leftLeg = root.getChild("leftLeg");
		this.rightLeg = root.getChild("rightLeg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition Helmet = head.addOrReplaceChild("Helmet", CubeListBuilder.create(), PartPose.offset(0.0F, -2.2504F, -4.6043F));

		PartDefinition Visor = Helmet.addOrReplaceChild("Visor", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -27.8007F, -7.3992F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F))
		.texOffs(123, 0).addBox(-1.0F, -29.8007F, -7.3992F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 26.2504F, 4.6043F));

		PartDefinition right8_r1 = Visor.addOrReplaceChild("right8_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, 1.505F, -1.8371F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-3.5F, -27.941F, -5.6703F, 0.4363F, 0.3491F, 0.0F));

		PartDefinition right12_r1 = Visor.addOrReplaceChild("right12_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -0.2689F, -0.8258F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F))
		.texOffs(123, 0).addBox(-1.0F, 1.7311F, -0.8258F, 2.0F, 2.9F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.7548F, -29.5317F, -5.0154F, 0.0F, -0.8727F, 0.0F));

		PartDefinition right13_r1 = Visor.addOrReplaceChild("right13_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -2.046F, -0.8672F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.7548F, -29.5317F, -5.0154F, -0.2618F, -0.8727F, 0.0F));

		PartDefinition right8_r2 = Visor.addOrReplaceChild("right8_r2", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -3.3383F, -1.774F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.7548F, -29.5317F, -5.0154F, -0.7854F, -0.8727F, 0.0F));

		PartDefinition right10_r1 = Visor.addOrReplaceChild("right10_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-1.0F, 1.7311F, -0.8258F, 2.0F, 2.9F, 0.5F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(123, 0).mirror().addBox(-1.0F, -0.2689F, -0.8258F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-4.7548F, -29.5317F, -5.0154F, 0.0F, 0.8727F, 0.0F));

		PartDefinition right7_r1 = Visor.addOrReplaceChild("right7_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-1.0F, -3.3383F, -1.774F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-4.7548F, -29.5317F, -5.0154F, -0.7854F, 0.8727F, 0.0F));

		PartDefinition right12_r2 = Visor.addOrReplaceChild("right12_r2", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-1.0F, -2.046F, -0.8672F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-4.7548F, -29.5317F, -5.0154F, -0.2618F, 0.8727F, 0.0F));

		PartDefinition right6_r1 = Visor.addOrReplaceChild("right6_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, -4.3195F, -3.0425F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-3.5F, -27.941F, -5.6703F, -0.7854F, 0.3491F, 0.0F));

		PartDefinition right9_r1 = Visor.addOrReplaceChild("right9_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, 0.1404F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(123, 0).mirror().addBox(-0.95F, -1.8596F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-3.5F, -27.941F, -5.6703F, 0.0F, 0.3491F, 0.0F));

		PartDefinition right11_r1 = Visor.addOrReplaceChild("right11_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, -3.5299F, -1.4751F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-3.5F, -27.941F, -5.6703F, -0.2618F, 0.3491F, 0.0F));

		PartDefinition right5_r1 = Visor.addOrReplaceChild("right5_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, -3.5299F, -1.4751F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.8F, -27.941F, -6.1703F, -0.2618F, 0.1745F, 0.0F));

		PartDefinition right4_r1 = Visor.addOrReplaceChild("right4_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, -1.8596F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(123, 0).mirror().addBox(-0.95F, 0.1404F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.8F, -27.941F, -6.1703F, 0.0F, 0.1745F, 0.0F));

		PartDefinition right2_r1 = Visor.addOrReplaceChild("right2_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, 1.505F, -1.8371F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.8F, -27.941F, -6.1703F, 0.4363F, 0.1745F, 0.0F));

		PartDefinition right0_r1 = Visor.addOrReplaceChild("right0_r1", CubeListBuilder.create().texOffs(123, 0).mirror().addBox(-0.95F, -4.3195F, -3.0425F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.8F, -27.941F, -6.1703F, -0.7854F, 0.1745F, 0.0F));

		PartDefinition left11_r1 = Visor.addOrReplaceChild("left11_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -3.5299F, -1.4751F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.5F, -27.941F, -5.6703F, -0.2618F, -0.3491F, 0.0F));

		PartDefinition left10_r1 = Visor.addOrReplaceChild("left10_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -1.8596F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F))
		.texOffs(123, 0).addBox(-1.05F, 0.1404F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.5F, -27.941F, -5.6703F, 0.0F, -0.3491F, 0.0F));

		PartDefinition left8_r1 = Visor.addOrReplaceChild("left8_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, 1.505F, -1.8371F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.5F, -27.941F, -5.6703F, 0.4363F, -0.3491F, 0.0F));

		PartDefinition left6_r1 = Visor.addOrReplaceChild("left6_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -4.3195F, -3.0425F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.5F, -27.941F, -5.6703F, -0.7854F, -0.3491F, 0.0F));

		PartDefinition left5_r1 = Visor.addOrReplaceChild("left5_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -3.5299F, -1.4751F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.8F, -27.941F, -6.1703F, -0.2618F, -0.1745F, 0.0F));

		PartDefinition left4_r1 = Visor.addOrReplaceChild("left4_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -1.8596F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F))
		.texOffs(123, 0).addBox(-1.05F, 0.1404F, -1.0289F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.8F, -27.941F, -6.1703F, 0.0F, -0.1745F, 0.0F));

		PartDefinition left2_r1 = Visor.addOrReplaceChild("left2_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, 1.505F, -1.8371F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.8F, -27.941F, -6.1703F, 0.4363F, -0.1745F, 0.0F));

		PartDefinition left0_r1 = Visor.addOrReplaceChild("left0_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.05F, -4.3195F, -3.0425F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.8F, -27.941F, -6.1703F, -0.7854F, -0.1745F, 0.0F));

		PartDefinition mid5_r1 = Visor.addOrReplaceChild("mid5_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -1.0F, -0.25F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -32.2628F, -5.9977F, -0.7854F, 0.0F, 0.0F));

		PartDefinition mid4_r1 = Visor.addOrReplaceChild("mid4_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -1.0F, -0.25F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -30.7019F, -6.8989F, -0.2618F, 0.0F, 0.0F));

		PartDefinition mid1_r1 = Visor.addOrReplaceChild("mid1_r1", CubeListBuilder.create().texOffs(123, 0).addBox(-1.0F, -1.0F, -0.25F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, -25.0F, -6.75F, 0.4363F, 0.0F, 0.0F));

		PartDefinition VisorBorder = Helmet.addOrReplaceChild("VisorBorder", CubeListBuilder.create().texOffs(125, 7).addBox(6.5302F, -1.9503F, -0.3758F, 0.4F, 2.0F, 1.0F, new CubeDeformation(0.0F))
		.texOffs(125, 7).mirror().addBox(-5.9302F, -1.9503F, -0.3758F, 0.4F, 2.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(125, 7).mirror().addBox(-5.9302F, -3.9503F, -0.3758F, 0.4F, 2.0F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(125, 7).addBox(6.5302F, -3.9503F, -0.3758F, 0.4F, 2.0F, 1.0F, new CubeDeformation(0.0F))
		.texOffs(1, 1).addBox(-0.5F, -7.4F, -1.1F, 2.0F, 0.4F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(-0.5F, 0.4F, 0.2F));

		PartDefinition cube_r1 = VisorBorder.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(111, 41).mirror().addBox(-0.05F, 3.4F, -0.5F, 0.1F, 0.4F, 0.1F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).mirror().addBox(-0.05F, 3.0F, -0.5F, 0.1F, 0.4F, 0.2F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).mirror().addBox(-0.05F, 2.6F, -0.5F, 0.1F, 0.4F, 0.3F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).mirror().addBox(-0.05F, 2.2F, -0.5F, 0.1F, 0.4F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).mirror().addBox(-0.05F, 1.8F, -0.5F, 0.1F, 0.4F, 0.5F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).mirror().addBox(-0.05F, 1.4F, -0.5F, 0.1F, 0.4F, 0.6F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 41).mirror().addBox(-0.05F, 1.0F, -0.5F, 0.1F, 0.4F, 0.7F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).mirror().addBox(-0.05F, 0.6F, -0.5F, 0.1F, 0.4F, 0.8F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).mirror().addBox(-0.05F, 0.2F, -0.5F, 0.1F, 0.4F, 0.9F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).mirror().addBox(-0.05F, -0.2F, -0.5F, 0.1F, 0.4F, 1.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(111, 41).addBox(12.05F, 3.4F, -0.5F, 0.1F, 0.4F, 0.1F, new CubeDeformation(0.0F))
		.texOffs(111, 41).addBox(12.05F, 3.0F, -0.5F, 0.1F, 0.4F, 0.2F, new CubeDeformation(0.0F))
		.texOffs(111, 41).addBox(12.05F, 2.6F, -0.5F, 0.1F, 0.4F, 0.3F, new CubeDeformation(0.0F))
		.texOffs(111, 41).addBox(12.05F, 2.2F, -0.5F, 0.1F, 0.4F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(111, 41).addBox(12.05F, 1.8F, -0.5F, 0.1F, 0.4F, 0.5F, new CubeDeformation(0.0F))
		.texOffs(111, 41).addBox(12.05F, 1.4F, -0.5F, 0.1F, 0.4F, 0.6F, new CubeDeformation(0.0F))
		.texOffs(110, 41).addBox(12.05F, 1.0F, -0.5F, 0.1F, 0.4F, 0.7F, new CubeDeformation(0.0F))
		.texOffs(110, 40).addBox(12.05F, 0.6F, -0.5F, 0.1F, 0.4F, 0.8F, new CubeDeformation(0.0F))
		.texOffs(110, 40).addBox(12.05F, 0.2F, -0.5F, 0.1F, 0.4F, 0.9F, new CubeDeformation(0.0F))
		.texOffs(110, 40).addBox(12.05F, -0.2F, -0.5F, 0.1F, 0.4F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.55F, -12.5094F, 3.6797F, -2.4871F, 0.0F, 0.0F));

		PartDefinition cube_r2 = VisorBorder.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(110, 40).mirror().addBox(-0.05F, -0.25F, -0.65F, 0.1F, 0.4F, 1.1F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).mirror().addBox(-0.05F, -0.65F, -0.65F, 0.1F, 0.4F, 1.2F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).mirror().addBox(-0.05F, -1.05F, -0.65F, 0.1F, 0.4F, 1.3F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).addBox(12.05F, -0.25F, -0.65F, 0.1F, 0.4F, 1.1F, new CubeDeformation(0.0F))
		.texOffs(110, 40).addBox(12.05F, -0.65F, -0.65F, 0.1F, 0.4F, 1.2F, new CubeDeformation(0.0F))
		.texOffs(110, 40).addBox(12.05F, -1.05F, -0.65F, 0.1F, 0.4F, 1.3F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.55F, -12.2302F, 3.7149F, -2.6442F, 0.0F, 0.0F));

		PartDefinition cube_r3 = VisorBorder.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(110, 40).mirror().addBox(-0.05F, -1.05F, -0.7F, 0.1F, 1.9F, 1.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).addBox(12.05F, -1.05F, -0.7F, 0.1F, 1.9F, 1.4F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.55F, -10.5864F, 4.4499F, -2.7489F, 0.0F, 0.0F));

		PartDefinition cube_r4 = VisorBorder.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(110, 40).mirror().addBox(0.05F, 1.25F, -0.65F, 0.1F, 1.9F, 1.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).addBox(12.15F, 1.25F, -0.65F, 0.1F, 1.9F, 1.4F, new CubeDeformation(0.0F))
		.texOffs(110, 40).mirror().addBox(-0.05F, -0.65F, -0.75F, 0.2F, 1.9F, 1.6F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(110, 40).addBox(12.15F, -0.65F, -0.75F, 0.2F, 1.9F, 1.6F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.65F, -6.7212F, 5.8259F, -2.8362F, 0.0F, 0.0F));

		PartDefinition cube_r5 = VisorBorder.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(108, 38).mirror().addBox(-0.25F, -0.7F, -0.7F, 0.3F, 1.9F, 3.7F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(108, 38).addBox(12.05F, -0.7F, -0.7F, 0.3F, 1.9F, 3.7F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.55F, -3.7F, 4.9F, 1.3526F, 0.0F, 0.0F));

		PartDefinition cube_r6 = VisorBorder.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(123, 35).mirror().addBox(-0.2F, -5.0F, -1.5F, 0.4F, 6.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(123, 35).addBox(12.2604F, -5.0F, -1.5F, 0.4F, 6.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.7302F, -0.7503F, 1.3242F, -1.0647F, 0.0F, 0.0F));

		PartDefinition cube_r7 = VisorBorder.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(117, 35).mirror().addBox(-0.2F, -4.9F, -1.4F, 0.4F, 6.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(117, 35).addBox(12.2604F, -4.9F, -1.4F, 0.4F, 6.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.7302F, -3.0503F, 1.3242F, -1.0647F, 0.0F, 0.0F));

		PartDefinition cube_r8 = VisorBorder.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(120, 30).mirror().addBox(2.1F, -7.4F, -2.35F, 1.6F, 0.4F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.0595F, 0.0F, -0.0205F, 0.0F, -0.7418F, 0.0F));

		PartDefinition cube_r9 = VisorBorder.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(120, 30).mirror().addBox(0.0F, -7.4F, -1.15F, 3.0F, 0.4F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.0F, 0.0F, 0.0F, 0.0F, -0.2618F, 0.0F));

		PartDefinition cube_r10 = VisorBorder.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(120, 30).addBox(-3.7F, -7.4F, -2.35F, 1.6F, 0.4F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0595F, 0.0F, -0.0205F, 0.0F, 0.7418F, 0.0F));

		PartDefinition cube_r11 = VisorBorder.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(120, 30).addBox(-3.0F, -7.4F, -1.15F, 3.0F, 0.4F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.2618F, 0.0F));

		PartDefinition cube_r12 = VisorBorder.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(0, 0).mirror().addBox(-1.0F, -1.8F, 0.35F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(0, 0).addBox(10.0F, -1.8F, 0.35F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-5.0F, 3.8991F, 3.4648F, 1.5708F, 0.0F, 0.0F));

		PartDefinition cube_r13 = VisorBorder.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(122, 24).addBox(-1.0F, -0.75F, -0.3F, 2.0F, 1.5F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.5F, 2.15F, -2.8F, 0.6109F, 0.0F, 0.0F));

		PartDefinition cube_r14 = VisorBorder.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(121, 19).mirror().addBox(-2.7F, -0.5F, -1.0F, 4.0F, 0.9F, 1.1F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(3.9F, 2.1F, -1.6F, -0.8492F, -0.2324F, -0.2F));

		PartDefinition cube_r15 = VisorBorder.addOrReplaceChild("cube_r15", CubeListBuilder.create().texOffs(121, 19).addBox(-1.3F, -0.5F, -1.0F, 4.0F, 0.9F, 1.1F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.9F, 2.1F, -1.6F, -0.8492F, 0.2324F, 0.2F));

		PartDefinition cube_r16 = VisorBorder.addOrReplaceChild("cube_r16", CubeListBuilder.create().texOffs(119, 12).addBox(0.05F, -1.0F, -1.6F, 0.4F, 1.4F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(6.05F, 1.0F, -0.5F, 0.6426F, 0.734F, 0.1767F));

		PartDefinition cube_r17 = VisorBorder.addOrReplaceChild("cube_r17", CubeListBuilder.create().texOffs(119, 12).mirror().addBox(-0.45F, -1.0F, -1.6F, 0.4F, 1.4F, 3.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-5.05F, 1.0F, -0.5F, 0.6426F, -0.734F, -0.1767F));

		PartDefinition cube_r18 = VisorBorder.addOrReplaceChild("cube_r18", CubeListBuilder.create().texOffs(125, 7).mirror().addBox(-0.4F, -1.1F, -0.5F, 0.4F, 2.1F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-4.6981F, -6.4413F, 0.8273F, -0.4338F, -0.2592F, 0.717F));

		PartDefinition cube_r19 = VisorBorder.addOrReplaceChild("cube_r19", CubeListBuilder.create().texOffs(125, 7).mirror().addBox(-0.2F, -1.1F, -0.5F, 0.4F, 2.1F, 1.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-5.5431F, -4.8204F, 0.243F, -0.1285F, 0.0249F, 0.1904F));

		PartDefinition cube_r20 = VisorBorder.addOrReplaceChild("cube_r20", CubeListBuilder.create().texOffs(125, 7).addBox(0.0F, -1.1F, -0.5F, 0.4F, 2.1F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(5.6981F, -6.4413F, 0.8273F, -0.4338F, 0.2592F, -0.717F));

		PartDefinition cube_r21 = VisorBorder.addOrReplaceChild("cube_r21", CubeListBuilder.create().texOffs(125, 7).addBox(-0.2F, -1.1F, -0.5F, 0.4F, 2.1F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(6.5431F, -4.8204F, 0.243F, -0.1285F, -0.0249F, -0.1904F));

		PartDefinition HelmetMain = Helmet.addOrReplaceChild("HelmetMain", CubeListBuilder.create().texOffs(106, 12).addBox(-0.9F, -7.1F, 0.1F, 2.0F, 0.6F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r22 = HelmetMain.addOrReplaceChild("cube_r22", CubeListBuilder.create().texOffs(105, 11).mirror().addBox(0.75F, -0.3F, -1.9F, 2.5F, 0.6F, 2.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(1.8404F, -6.8F, 1.3374F, 0.0F, -0.6981F, 0.0F));

		PartDefinition cube_r23 = HelmetMain.addOrReplaceChild("cube_r23", CubeListBuilder.create().texOffs(106, 12).mirror().addBox(-0.1F, -0.3F, -1.1F, 2.5F, 0.6F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.7119F, -6.8F, 1.1884F, 0.0F, -0.2618F, 0.0F));

		PartDefinition cube_r24 = HelmetMain.addOrReplaceChild("cube_r24", CubeListBuilder.create().texOffs(106, 12).addBox(-3.35F, -0.2F, -1.3F, 6.5F, 0.4F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.559F, -6.7F, 5.4139F, 0.0F, 1.5446F, 0.0F));

		PartDefinition cube_r25 = HelmetMain.addOrReplaceChild("cube_r25", CubeListBuilder.create().texOffs(106, 12).mirror().addBox(-3.15F, -0.2F, -1.3F, 6.5F, 0.4F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.559F, -6.7F, 5.4139F, 0.0F, -1.5446F, 0.0F));

		PartDefinition cube_r26 = HelmetMain.addOrReplaceChild("cube_r26", CubeListBuilder.create().texOffs(106, 12).mirror().addBox(0.05F, -0.1F, -1.25F, 6.5F, 0.4F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(3.7903F, -6.8F, 2.1251F, 0.0F, -1.4399F, 0.0F));

		PartDefinition cube_r27 = HelmetMain.addOrReplaceChild("cube_r27", CubeListBuilder.create().texOffs(106, 12).addBox(-6.55F, -0.1F, -1.25F, 6.5F, 0.4F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.7903F, -6.8F, 2.1251F, 0.0F, 1.4399F, 0.0F));

		PartDefinition cube_r28 = HelmetMain.addOrReplaceChild("cube_r28", CubeListBuilder.create().texOffs(105, 11).addBox(-3.25F, -0.3F, -1.9F, 2.5F, 0.6F, 2.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-1.8404F, -6.8F, 1.3374F, 0.0F, 0.6981F, 0.0F));

		PartDefinition cube_r29 = HelmetMain.addOrReplaceChild("cube_r29", CubeListBuilder.create().texOffs(106, 12).addBox(-2.4F, -0.3F, -1.1F, 2.5F, 0.6F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.7119F, -6.8F, 1.1884F, 0.0F, 0.2618F, 0.0F));

		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition Armor = body.addOrReplaceChild("Armor", CubeListBuilder.create().texOffs(110, 88).addBox(-3.4333F, -2.3705F, -1.0309F, 7.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0333F, 3.0705F, -2.0691F));

		PartDefinition BreastplateL2_r1 = Armor.addOrReplaceChild("BreastplateL2_r1", CubeListBuilder.create().texOffs(100, 55).mirror().addBox(-0.6F, -2.0F, 0.7F, 1.6F, 2.0F, 0.3F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.8333F, 0.9F, -1.4F, 0.0F, 0.0F, 0.3927F));

		PartDefinition BreastplateL1_r1 = Armor.addOrReplaceChild("BreastplateL1_r1", CubeListBuilder.create().texOffs(100, 52).mirror().addBox(-1.0F, -2.0F, 0.7F, 2.0F, 2.0F, 0.3F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.4333F, 0.0F, -1.4F, 0.0F, 0.0F, 0.829F));

		PartDefinition BreastplateR2_r1 = Armor.addOrReplaceChild("BreastplateR2_r1", CubeListBuilder.create().texOffs(100, 55).addBox(-1.0F, -2.0F, 0.7F, 1.6F, 2.0F, 0.3F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.9F, 0.9F, -1.4F, 0.0F, 0.0F, -0.3927F));

		PartDefinition BreastplateR1_r1 = Armor.addOrReplaceChild("BreastplateR1_r1", CubeListBuilder.create().texOffs(100, 52).addBox(-1.0F, -2.0F, 0.7F, 2.0F, 2.0F, 0.3F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.5F, 0.0F, -1.4F, 0.0F, 0.0F, -0.829F));

		PartDefinition BreastplateCore2_r1 = Armor.addOrReplaceChild("BreastplateCore2_r1", CubeListBuilder.create().texOffs(116, 99).addBox(-3.0F, -3.0F, -0.65F, 4.0F, 4.0F, 1.55F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0333F, 2.0295F, 0.0691F, 0.0309F, -0.0308F, 0.7849F));

		PartDefinition BreastplateCore1_r1 = Armor.addOrReplaceChild("BreastplateCore1_r1", CubeListBuilder.create().texOffs(117, 81).addBox(-1.5F, -1.5F, -1.1F, 3.0F, 3.0F, 2.1F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-0.0333F, 0.2505F, -0.0522F, 0.124F, -0.1231F, 0.7777F));

		PartDefinition HipArmor = Armor.addOrReplaceChild("HipArmor", CubeListBuilder.create().texOffs(96, 109).addBox(-8.2313F, -2.3432F, -2.525F, 9.3F, 1.0F, 5.2F, new CubeDeformation(0.0F))
		.texOffs(87, 96).addBox(1.0688F, -0.8432F, -1.925F, 0.25F, 3.0F, 3.8F, new CubeDeformation(0.0F))
		.texOffs(87, 96).mirror().addBox(-8.4479F, -0.8432F, -1.925F, 0.25F, 3.0F, 3.8F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(3.5313F, 10.5432F, 2.025F));

		PartDefinition HipArmorBaseR3_r1 = HipArmor.addOrReplaceChild("HipArmorBaseR3_r1", CubeListBuilder.create().texOffs(88, 97).mirror().addBox(-0.125F, -1.0F, -1.0F, 0.25F, 3.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(88, 97).addBox(9.3917F, -1.0F, -1.0F, 0.25F, 3.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-8.3229F, 1.4568F, -0.025F, -0.7854F, 0.0F, 0.0F));

		PartDefinition HipArmorBaseR1_r1 = HipArmor.addOrReplaceChild("HipArmorBaseR1_r1", CubeListBuilder.create().texOffs(88, 97).mirror().addBox(-0.125F, -1.2F, -1.2F, 0.25F, 3.2F, 3.2F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(88, 97).addBox(9.3917F, -1.2F, -1.2F, 0.25F, 3.2F, 3.2F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-8.3229F, -1.5432F, -0.025F, -0.7854F, 0.0F, 0.0F));

		PartDefinition HipArmorGemR3_r1 = HipArmor.addOrReplaceChild("HipArmorGemR3_r1", CubeListBuilder.create().texOffs(91, 84).mirror().addBox(-0.2F, -1.0F, -1.0F, 0.4F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-8.5292F, 2.0F, 0.0F, 0.0F, 0.0F, -0.0698F));

		PartDefinition HipArmorGemR2_r1 = HipArmor.addOrReplaceChild("HipArmorGemR2_r1", CubeListBuilder.create().texOffs(91, 84).mirror().addBox(-0.25F, -1.0F, -1.0F, 0.5F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(91, 84).addBox(9.7792F, -1.0F, -1.0F, 0.5F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-8.5792F, 0.1F, 0.0F, 0.0F, 0.0F, 0.0F));

		PartDefinition HipArmorGemR1_r1 = HipArmor.addOrReplaceChild("HipArmorGemR1_r1", CubeListBuilder.create().texOffs(91, 84).mirror().addBox(-0.1F, -1.0F, -1.0F, 0.5F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(91, 84).addBox(9.9292F, -1.0F, -1.0F, 0.5F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-8.7292F, -1.0F, 0.0F, 0.7854F, 0.0F, 0.0F));

		PartDefinition HipArmorGemL3_r1 = HipArmor.addOrReplaceChild("HipArmorGemL3_r1", CubeListBuilder.create().texOffs(91, 84).addBox(-0.2F, -1.0F, -1.0F, 0.4F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.4F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0698F));

		PartDefinition leftArm = partdefinition.addOrReplaceChild("leftArm", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.offset(5.0F, 2.0F, 0.0F));

		PartDefinition VambraceL = leftArm.addOrReplaceChild("VambraceL", CubeListBuilder.create().texOffs(86, 64).addBox(-1.6F, 5.6F, -2.6F, 5.25F, 4.0F, 5.2F, new CubeDeformation(0.0F))
		.texOffs(106, 122).addBox(-1.7F, 9.45F, -2.7F, 5.5F, 0.25F, 5.4F, new CubeDeformation(0.0F))
		.texOffs(106, 122).addBox(-1.7F, 5.45F, -2.7F, 5.5F, 0.25F, 5.4F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r30 = VambraceL.addOrReplaceChild("cube_r30", CubeListBuilder.create().texOffs(77, 111).addBox(1.1F, -1.0F, -0.025F, 2.0F, 1.8F, 0.0F, new CubeDeformation(0.0F))
		.texOffs(77, 114).addBox(-0.9F, -1.0F, -0.175F, 2.0F, 1.9F, 0.35F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(5.3564F, 5.5102F, 0.125F, 0.0F, 0.0F, -0.6109F));

		PartDefinition cube_r31 = VambraceL.addOrReplaceChild("cube_r31", CubeListBuilder.create().texOffs(83, 114).addBox(-1.0F, -1.0F, -0.175F, 2.0F, 2.0F, 0.35F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.8F, 6.6F, 0.125F, 0.0F, 0.0F, -0.6109F));

		PartDefinition PauldronL = leftArm.addOrReplaceChild("PauldronL", CubeListBuilder.create(), PartPose.offsetAndRotation(4.1331F, -1.6538F, 0.0F, 0.0F, 0.0F, 0.1396F));

		PartDefinition Gem5_r1 = PauldronL.addOrReplaceChild("Gem5_r1", CubeListBuilder.create().texOffs(50, 112).addBox(-0.075F, -1.35F, -1.4F, 0.15F, 2.7F, 2.85F, new CubeDeformation(0.0F))
		.texOffs(50, 112).addBox(-0.225F, -1.45F, -1.5F, 0.15F, 2.9F, 3.05F, new CubeDeformation(0.0F))
		.texOffs(50, 112).addBox(-0.375F, -1.55F, -1.6F, 0.15F, 3.1F, 3.25F, new CubeDeformation(0.0F))
		.texOffs(50, 112).addBox(-0.625F, -1.65F, -1.7F, 0.25F, 3.3F, 3.45F, new CubeDeformation(0.0F))
		.texOffs(49, 111).addBox(-0.875F, -1.75F, -1.8F, 0.25F, 3.5F, 3.65F, new CubeDeformation(0.0F))
		.texOffs(84, 118).addBox(-1.825F, -2.35F, -2.35F, 0.25F, 4.7F, 4.7F, new CubeDeformation(0.0F))
		.texOffs(74, 119).addBox(-1.575F, -2.25F, -2.25F, 0.25F, 4.5F, 4.5F, new CubeDeformation(0.0F))
		.texOffs(75, 119).addBox(-1.325F, -2.15F, -2.15F, 0.25F, 4.3F, 4.3F, new CubeDeformation(0.0F))
		.texOffs(75, 120).addBox(-1.125F, -2.0F, -2.0F, 0.25F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(1.2919F, -0.3462F, 0.0F, 0.0F, 0.0F, -0.2618F));

		PartDefinition rightArm = partdefinition.addOrReplaceChild("rightArm", CubeListBuilder.create().texOffs(32, 48).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.offset(-5.0F, 2.0F, 0.0F));

		PartDefinition VambraceR = rightArm.addOrReplaceChild("VambraceR", CubeListBuilder.create().texOffs(86, 64).mirror().addBox(-3.65F, 5.6F, -2.6F, 5.25F, 4.0F, 5.2F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(106, 122).mirror().addBox(-3.8F, 9.45F, -2.7F, 5.5F, 0.25F, 5.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(106, 122).mirror().addBox(-3.8F, 5.45F, -2.7F, 5.5F, 0.25F, 5.4F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r32 = VambraceR.addOrReplaceChild("cube_r32", CubeListBuilder.create().texOffs(77, 111).mirror().addBox(-3.1F, -1.0F, -0.025F, 2.0F, 1.8F, 0.0F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(77, 114).mirror().addBox(-1.1F, -1.0F, -0.175F, 2.0F, 1.9F, 0.35F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-5.3564F, 5.5102F, 0.125F, 0.0F, 0.0F, 0.6109F));

		PartDefinition cube_r33 = VambraceR.addOrReplaceChild("cube_r33", CubeListBuilder.create().texOffs(83, 114).mirror().addBox(-1.0F, -1.0F, -0.175F, 2.0F, 2.0F, 0.35F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-3.8F, 6.6F, 0.125F, 0.0F, 0.0F, 0.6109F));

		PartDefinition PauldronR = rightArm.addOrReplaceChild("PauldronR", CubeListBuilder.create(), PartPose.offsetAndRotation(-4.1331F, -1.6538F, 0.0F, 0.0F, 0.0F, -0.1396F));

		PartDefinition Gem6_r1 = PauldronR.addOrReplaceChild("Gem6_r1", CubeListBuilder.create().texOffs(50, 112).mirror().addBox(-0.075F, -1.35F, -1.4F, 0.15F, 2.7F, 2.85F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(50, 112).mirror().addBox(0.075F, -1.45F, -1.5F, 0.15F, 2.9F, 3.05F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(50, 112).mirror().addBox(0.225F, -1.55F, -1.6F, 0.15F, 3.1F, 3.25F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(50, 112).mirror().addBox(0.375F, -1.65F, -1.7F, 0.25F, 3.3F, 3.45F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(49, 111).mirror().addBox(0.625F, -1.75F, -1.8F, 0.25F, 3.5F, 3.65F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(84, 118).mirror().addBox(1.575F, -2.35F, -2.35F, 0.25F, 4.7F, 4.7F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(74, 119).mirror().addBox(1.325F, -2.25F, -2.25F, 0.25F, 4.5F, 4.5F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(75, 119).mirror().addBox(1.075F, -2.15F, -2.15F, 0.25F, 4.3F, 4.3F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(75, 120).mirror().addBox(0.875F, -2.0F, -2.0F, 0.25F, 4.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-1.2919F, -0.3462F, 0.0F, 0.0F, 0.0F, 0.2618F));

		PartDefinition leftLeg = partdefinition.addOrReplaceChild("leftLeg", CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.25F)), PartPose.offset(1.9F, 12.0F, 0.0F));

		PartDefinition Boot = leftLeg.addOrReplaceChild("Boot", CubeListBuilder.create().texOffs(0, 119).addBox(-2.4F, 8.5F, -2.3F, 4.8F, 3.9F, 4.6F, new CubeDeformation(0.0F))
		.texOffs(25, 124).addBox(-2.4F, 8.75F, -2.4F, 4.8F, 3.65F, 0.1F, new CubeDeformation(0.0F))
		.texOffs(25, 124).addBox(-2.4F, 8.85F, -2.5F, 4.8F, 3.55F, 0.1F, new CubeDeformation(0.0F))
		.texOffs(25, 124).addBox(-2.4F, 8.95F, -2.6F, 4.8F, 3.45F, 0.1F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-2.4F, 9.05F, -3.0F, 4.8F, 3.35F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-2.3F, 9.15F, -3.4F, 4.6F, 3.25F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-2.2F, 9.25F, -3.8F, 4.4F, 3.15F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-2.0F, 9.45F, -4.2F, 4.0F, 2.95F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-1.9F, 9.55F, -4.6F, 3.8F, 2.85F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-1.8F, 9.65F, -5.0F, 3.6F, 2.75F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-1.7F, 9.8F, -5.4F, 3.4F, 2.6F, 0.4F, new CubeDeformation(0.0F))
		.texOffs(24, 123).addBox(-1.6F, 10.05F, -5.8F, 3.2F, 2.35F, 0.4F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition Kneepad = leftLeg.addOrReplaceChild("Kneepad", CubeListBuilder.create().texOffs(58, 122).addBox(-2.3F, 4.5F, -2.3F, 4.6F, 1.0F, 4.6F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r34 = Kneepad.addOrReplaceChild("cube_r34", CubeListBuilder.create().texOffs(43, 125).addBox(-1.0F, -1.0F, -0.25F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 5.0F, -2.25F, 0.0F, 0.0F, -0.7854F));

		PartDefinition rightLeg = partdefinition.addOrReplaceChild("rightLeg", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.25F)), PartPose.offset(-1.9F, 12.0F, 0.0F));

		PartDefinition Boot2 = rightLeg.addOrReplaceChild("Boot2", CubeListBuilder.create().texOffs(0, 119).mirror().addBox(-2.4F, 8.5F, -2.3F, 4.8F, 3.9F, 4.6F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(25, 124).mirror().addBox(-2.4F, 8.75F, -2.4F, 4.8F, 3.65F, 0.1F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(25, 124).mirror().addBox(-2.4F, 8.85F, -2.5F, 4.8F, 3.55F, 0.1F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(25, 124).mirror().addBox(-2.4F, 8.95F, -2.6F, 4.8F, 3.45F, 0.1F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-2.4F, 9.05F, -3.0F, 4.8F, 3.35F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-2.3F, 9.15F, -3.4F, 4.6F, 3.25F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-2.2F, 9.25F, -3.8F, 4.4F, 3.15F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-2.0F, 9.45F, -4.2F, 4.0F, 2.95F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-1.9F, 9.55F, -4.6F, 3.8F, 2.85F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-1.8F, 9.65F, -5.0F, 3.6F, 2.75F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-1.7F, 9.8F, -5.4F, 3.4F, 2.6F, 0.4F, new CubeDeformation(0.0F)).mirror(false)
		.texOffs(24, 123).mirror().addBox(-1.6F, 10.05F, -5.8F, 3.2F, 2.35F, 0.4F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition Kneepad2 = rightLeg.addOrReplaceChild("Kneepad2", CubeListBuilder.create().texOffs(58, 122).mirror().addBox(-2.3F, 4.5F, -2.3F, 4.6F, 1.0F, 4.6F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition cube_r35 = Kneepad2.addOrReplaceChild("cube_r35", CubeListBuilder.create().texOffs(43, 125).mirror().addBox(-1.0F, -1.0F, -0.25F, 2.0F, 2.0F, 0.5F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(0.0F, 5.0F, -2.25F, 0.0F, 0.0F, 0.7854F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		leftArm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		rightArm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		leftLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		rightLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}