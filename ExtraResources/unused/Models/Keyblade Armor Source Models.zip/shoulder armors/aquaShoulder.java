// Made with Blockbench 4.7.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports


public class AquaArmor<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("modid", "aquaarmor"), "main");
	private final ModelPart leftArm;

	public AquaArmor(ModelPart root) {
		this.leftArm = root.getChild("leftArm");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition leftArm = partdefinition.addOrReplaceChild("leftArm", CubeListBuilder.create().texOffs(40, 16).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.5F)), PartPose.offset(5.0F, 2.0F, 0.0F));

		PartDefinition leftArmExtras = leftArm.addOrReplaceChild("leftArmExtras", CubeListBuilder.create().texOffs(58, 9).addBox(3.5F, -2.0F, -1.25F, 0.25F, 4.25F, 2.5F, new CubeDeformation(0.0F)), PartPose.offset(-1.4F, 0.0F, 0.0F));

		PartDefinition cube_r1 = leftArmExtras.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(44, 1).addBox(-0.65F, -0.7F, -0.5061F, 1.2F, 1.0F, 1.2F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.5697F, 7.2F, 0.1061F, -3.1416F, -0.7854F, -2.8362F));

		PartDefinition cube_r2 = leftArmExtras.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(44, 1).addBox(-0.65F, -0.9F, -0.5061F, 1.2F, 1.4F, 1.2F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.4697F, 7.5F, 0.1061F, -3.1416F, -0.7854F, -2.4871F));

		PartDefinition cube_r3 = leftArmExtras.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(44, 1).addBox(-0.4F, -1.0F, -0.4F, 1.4F, 1.5F, 1.4F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.0F, 6.5F, 0.0F, -3.1416F, -0.7854F, 2.9671F));

		PartDefinition cube_r4 = leftArmExtras.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(36, 6).addBox(-0.1F, -0.9F, 0.1F, 0.25F, 0.8F, 0.8F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.9F, 4.6F, 0.0F, 0.7854F, 0.0F, 2.6878F));

		PartDefinition cube_r5 = leftArmExtras.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(35, 5).addBox(0.3F, -0.7F, -0.8F, 0.05F, 1.5F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.3F, 4.1F, 0.0F, 0.7854F, 0.0F, -3.1154F));

		PartDefinition cube_r6 = leftArmExtras.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(35, 5).addBox(0.3F, -0.9F, -1.0F, 0.05F, 1.9F, 1.9F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.3F, 4.7F, 0.0F, 0.7854F, 0.0F, -3.1154F));

		PartDefinition cube_r7 = leftArmExtras.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(34, 4).addBox(0.0F, -2.0F, -1.0F, 0.55F, 3.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.0F, 6.0F, 0.0F, 0.7854F, 0.0F, -3.0805F));

		PartDefinition Gem4_r1 = leftArmExtras.addOrReplaceChild("Gem4_r1", CubeListBuilder.create().texOffs(52, 4).addBox(-0.15F, -0.625F, -0.75F, 0.9F, 1.25F, 0.9F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.6464F, -0.775F, 0.0F, 0.0F, -0.7854F, -1.0385F));

		PartDefinition Gem3_r1 = leftArmExtras.addOrReplaceChild("Gem3_r1", CubeListBuilder.create().texOffs(51, 4).addBox(-1.0F, -0.75F, -0.45F, 1.45F, 2.05F, 1.45F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.6F, 1.75F, 0.0F, 0.0F, -0.7854F, 0.4363F));

		PartDefinition Gem1_r1 = leftArmExtras.addOrReplaceChild("Gem1_r1", CubeListBuilder.create().texOffs(51, 4).addBox(-1.0F, -0.75F, -0.45F, 1.45F, 1.45F, 1.45F, new CubeDeformation(0.0F))
		.texOffs(51, 4).addBox(-1.0F, -2.1F, -0.5F, 1.5F, 1.35F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(4.0F, 0.75F, 0.0F, 0.0F, -0.7854F, 0.0F));

		PartDefinition shoulderPlate_r1 = leftArmExtras.addOrReplaceChild("shoulderPlate_r1", CubeListBuilder.create().texOffs(58, 9).addBox(-0.125F, -0.625F, -1.25F, 0.15F, 1.25F, 2.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.625F, -0.675F, 1.75F, -0.7418F, 0.0F, 0.0F));

		PartDefinition shoulderPlate_r2 = leftArmExtras.addOrReplaceChild("shoulderPlate_r2", CubeListBuilder.create().texOffs(58, 9).addBox(-0.125F, -0.625F, -1.25F, 0.15F, 0.95F, 2.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.625F, 0.975F, 2.5F, -1.5708F, -0.4102F, 0.0F));

		PartDefinition shoulderPlate_r3 = leftArmExtras.addOrReplaceChild("shoulderPlate_r3", CubeListBuilder.create().texOffs(58, 9).addBox(-0.125F, -0.625F, -1.25F, 0.25F, 0.95F, 2.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.625F, 0.975F, -2.3F, 1.5708F, 0.4102F, 0.0F));

		PartDefinition shoulderPlate_r4 = leftArmExtras.addOrReplaceChild("shoulderPlate_r4", CubeListBuilder.create().texOffs(58, 9).addBox(-0.125F, -0.625F, -1.25F, 0.25F, 1.25F, 2.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.625F, -0.675F, -1.75F, 0.7418F, 0.0F, 0.0F));

		PartDefinition shoulderPlate_r5 = leftArmExtras.addOrReplaceChild("shoulderPlate_r5", CubeListBuilder.create().texOffs(58, 9).addBox(-0.875F, -1.125F, -0.75F, 0.8F, 1.75F, 1.75F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(3.725F, 2.525F, 0.1F, 0.7854F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		leftArm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}